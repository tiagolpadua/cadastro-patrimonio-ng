namespace cadpat {
    'use strict';
    angular.module('cadpat', [
        'ngRoute',
        'ui.bootstrap',
        'cadpatFilters',
        'cadpatServices',
        'alertaControllers',
        'alertaServices',
        'bemControllers'
    ]);
}
