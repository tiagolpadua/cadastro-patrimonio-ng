namespace cadpat {
    'use strict';
    angular.module('cadpat', [
        'ngRoute',
        'cadpatFilters',
        'cadpatServices',
        'bemControllers'
    ]);
}
