var cadpat;
(function (cadpat) {
    'use strict';
    angular.module('cadpat', [
        'ngRoute',
        'cadpatFilters',
        'cadpatServices',
        'bemControllers'
    ]);
})(cadpat || (cadpat = {}));
